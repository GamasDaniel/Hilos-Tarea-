﻿using System;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        // Crear e iniciar un hilo para la operación costosa
        Thread t = new Thread(OperacionCostosa);
        t.Start();

        // Mientras el hilo está trabajando, la aplicación principal puede hacer otras cosas
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine($"Trabajando en la tarea principal... ({i + 1}/5)");
            Thread.Sleep(1000); // Simular trabajo en la tarea principal
        }

        // Esperar a que el hilo termine antes de salir
        t.Join();

        Console.WriteLine("Tarea principal completada.");
    }

    static void OperacionCostosa()
    {
        // Simular una operación costosa
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine($"Realizando operación costosa... ({i + 1}/5)");
            Thread.Sleep(2000); // Simular trabajo en la operación costosa
        }
        Console.WriteLine("Operación costosa completada.");
    }
}
